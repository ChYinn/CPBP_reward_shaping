..
   DO NOT DELETE THIS FILE! It contains the all-important `.. autosummary::` directive with `:recursive:` option, without
   which API documentation wouldn't get extracted from docstrings by the `sphinx.ext.autosummary` engine. It is hidden
   (not declared in any toctree) to remove an unnecessary intermediate page; index.rst instead points directly to the
   package page. DO NOT REMOVE THIS FILE!

.. autosummary::
   :toctree: reference
   :template: base.rst
   :recursive:

   jacinle
   jaclearn
   jactf
   jactorch

