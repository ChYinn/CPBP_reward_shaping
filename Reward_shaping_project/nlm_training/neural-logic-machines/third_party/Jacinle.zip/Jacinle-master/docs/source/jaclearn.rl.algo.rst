jaclearn.rl.algo package
========================

.. automodule:: jaclearn.rl.algo
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.rl.algo.advantage module
---------------------------------

.. automodule:: jaclearn.rl.algo.advantage
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.rl.algo.math module
----------------------------

.. automodule:: jaclearn.rl.algo.math
   :members:
   :undoc-members:
   :show-inheritance:
