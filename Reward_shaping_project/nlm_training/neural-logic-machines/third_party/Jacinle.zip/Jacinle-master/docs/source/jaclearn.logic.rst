jaclearn.logic package
======================

.. automodule:: jaclearn.logic
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 2

   jaclearn.logic.decision_tree
   jaclearn.logic.propositional
