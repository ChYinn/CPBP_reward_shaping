jacinle.web.app package
=======================

.. automodule:: jacinle.web.app
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jacinle.web.app.application module
----------------------------------

.. automodule:: jacinle.web.app.application
   :members:
   :undoc-members:
   :show-inheritance:
