jaclearn.logic.propositional package
====================================

.. automodule:: jaclearn.logic.propositional
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 2

   jaclearn.logic.propositional.logic_induction
