jaclearn.models.naive\_bayes package
====================================

.. automodule:: jaclearn.models.naive_bayes
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.models.naive\_bayes.hybrid\_nb module
----------------------------------------------

.. automodule:: jaclearn.models.naive_bayes.hybrid_nb
   :members:
   :undoc-members:
   :show-inheritance:
