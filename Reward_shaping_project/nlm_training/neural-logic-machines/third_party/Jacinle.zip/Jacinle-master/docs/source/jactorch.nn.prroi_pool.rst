jactorch.nn.prroi\_pool package
===============================

.. automodule:: jactorch.nn.prroi_pool
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jactorch.nn.prroi\_pool.functional module
-----------------------------------------

.. automodule:: jactorch.nn.prroi_pool.functional
   :members:
   :undoc-members:
   :show-inheritance:
