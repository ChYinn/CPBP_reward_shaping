jaclearn.imageaug package
=========================

.. automodule:: jaclearn.imageaug
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.imageaug.cblk module
-----------------------------

.. automodule:: jaclearn.imageaug.cblk
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.imageaug.executor module
---------------------------------

.. automodule:: jaclearn.imageaug.executor
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.imageaug.photography module
------------------------------------

.. automodule:: jaclearn.imageaug.photography
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.imageaug.shape module
------------------------------

.. automodule:: jaclearn.imageaug.shape
   :members:
   :undoc-members:
   :show-inheritance:
