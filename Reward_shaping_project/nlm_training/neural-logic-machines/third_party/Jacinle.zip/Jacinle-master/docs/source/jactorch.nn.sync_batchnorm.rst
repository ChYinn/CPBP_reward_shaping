jactorch.nn.sync\_batchnorm package
===================================

.. automodule:: jactorch.nn.sync_batchnorm
   :members:
   :undoc-members:
   :show-inheritance:
