jaclearn.datasets.image\_classification package
===============================================

.. automodule:: jaclearn.datasets.image_classification
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.datasets.image\_classification.cifar module
----------------------------------------------------

.. automodule:: jaclearn.datasets.image_classification.cifar
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.datasets.image\_classification.mnist module
----------------------------------------------------

.. automodule:: jaclearn.datasets.image_classification.mnist
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.datasets.image\_classification.svhn module
---------------------------------------------------

.. automodule:: jaclearn.datasets.image_classification.svhn
   :members:
   :undoc-members:
   :show-inheritance:
