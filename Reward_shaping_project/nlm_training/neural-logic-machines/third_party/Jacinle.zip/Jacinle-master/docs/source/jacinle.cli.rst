jacinle.cli package
===================

.. automodule:: jacinle.cli
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jacinle.cli.argument module
---------------------------

.. automodule:: jacinle.cli.argument
   :members:
   :undoc-members:
   :show-inheritance:

jacinle.cli.device module
-------------------------

.. automodule:: jacinle.cli.device
   :members:
   :undoc-members:
   :show-inheritance:

jacinle.cli.git module
----------------------

.. automodule:: jacinle.cli.git
   :members:
   :undoc-members:
   :show-inheritance:

jacinle.cli.keyboard module
---------------------------

.. automodule:: jacinle.cli.keyboard
   :members:
   :undoc-members:
   :show-inheritance:
