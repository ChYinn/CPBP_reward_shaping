jactorch.models.vision package
==============================

.. automodule:: jactorch.models.vision
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jactorch.models.vision.resnet module
------------------------------------

.. automodule:: jactorch.models.vision.resnet
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.models.vision.vgg module
---------------------------------

.. automodule:: jactorch.models.vision.vgg
   :members:
   :undoc-members:
   :show-inheritance:
