jacinle.nd package
==================

.. automodule:: jacinle.nd
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jacinle.nd.batch module
-----------------------

.. automodule:: jacinle.nd.batch
   :members:
   :undoc-members:
   :show-inheritance:

jacinle.nd.indexing module
--------------------------

.. automodule:: jacinle.nd.indexing
   :members:
   :undoc-members:
   :show-inheritance:

jacinle.nd.meta module
----------------------

.. automodule:: jacinle.nd.meta
   :members:
   :undoc-members:
   :show-inheritance:

jacinle.nd.shape module
-----------------------

.. automodule:: jacinle.nd.shape
   :members:
   :undoc-members:
   :show-inheritance:
