jaclearn.logic.propositional.logic\_induction package
=====================================================

.. automodule:: jaclearn.logic.propositional.logic_induction
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.logic.propositional.logic\_induction.logic\_induction module
---------------------------------------------------------------------

.. automodule:: jaclearn.logic.propositional.logic_induction.logic_induction
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.logic.propositional.logic\_induction.setup module
----------------------------------------------------------

.. automodule:: jaclearn.logic.propositional.logic_induction.setup
   :members:
   :undoc-members:
   :show-inheritance:
